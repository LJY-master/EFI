# Hackintosh-EFI-for-Gigabyte-Z390-Aorus-Elite
</hr>
<strong>The Clove file have been tested on Catalina 10.15.2</strong>

Just download the CLOVER file, and replace the original one with DiskGenus, Just try it, lol.<br><br></hr>

<b>
Hardware:<br>
Processor : Intel Core i7-9700K<br>
Motherboard : Gigabyte Z390 Aorus Elite<br>
RAM : G.SKILL 8G DDR4 3200 GHz *4<br>
GPU : Sapphire RX 590 8G D5<br>
Storage : Intel 760P 512GB<br>
Wifi : NO hardware now<br>
Monitor : Dell 2518D<br>
Boot Mode : UEFI<br>
OSX Version : macOS Catalina 10.15.2<br>
</b>


